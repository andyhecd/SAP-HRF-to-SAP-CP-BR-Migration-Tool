"use strict";

// const cds = require("@sap/cds");
// const cdsLogger = require("../logger").cdsLogger;
/**
 * @param {import("@sap/cds/apis/services").Service} srv
 */
module.exports = (srv) => {};
